package io.swagger.api;

import io.swagger.model.Badges;

import io.swagger.annotations.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


@javax.annotation.Generated(value = "class io.swagger.codegen.languages.SpringCodegen", date = "2016-11-26T15:09:10.317Z")

@Controller
public class BadgesApiController implements BadgesApi {

    public ResponseEntity<List<Badges>> badgesGet() {
        // do some magic!
        return new ResponseEntity<List<Badges>>(HttpStatus.OK);
    }

    public ResponseEntity<Void> badgesPost(@ApiParam(value = "The info required to create a badge" ,required=true ) @RequestBody Badges badge) {
        // do some magic!
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

}
